SELECT DISTINCT dname
FROM Doctor NATURAL JOIN Patient NATURAL JOIN Visit
WHERE gender='M' AND bmi>30 AND specialty='pediatrician'
ORDER BY dname ASC;
