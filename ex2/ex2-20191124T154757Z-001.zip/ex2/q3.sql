SELECT DISTINCT pid,pname FROM Visit NATURAL JOIN Doctor NATURAL JOIN Patient WHERE specialty='orthopedist' OR specialty='pediatrician' ORDER BY pid,pname ASC;
