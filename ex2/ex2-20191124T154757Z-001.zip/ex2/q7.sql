SELECT DISTINCT did, max(fee), min(fee), avg(fee)
FROM Visit
GROUP BY did
ORDER BY did ASC;
